﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

struct Pessoa
{
    public string nome;
    public string email;
    public string telefone;
    public string categoria;
}

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Pessoa pessoa;

        public Form1()
        {
            InitializeComponent();
            ConfigurarListView();
        }

        private void ConfigurarListView()
        {
            // Configurar o ListView
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;

            // Adicionar colunas
            listView1.Columns.Add("Nome", 120);
            listView1.Columns.Add("Email", 120);
            listView1.Columns.Add("Telefone", 100);
            listView1.Columns.Add("Categoria", 100);
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            pessoa.nome = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            pessoa.email = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            pessoa.telefone = textBox3.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            pessoa.categoria = textBox4.Text;
        }

        // BOTÃO CRIAR (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            // Validação
            if (string.IsNullOrWhiteSpace(pessoa.nome))
            {
                MessageBox.Show("Por favor, preencha o nome!");
                return;
            }

            // Criar um item com os dados
            ListViewItem item = new ListViewItem(pessoa.nome);
            item.SubItems.Add(pessoa.email);
            item.SubItems.Add(pessoa.telefone);
            item.SubItems.Add(pessoa.categoria);

            // Adicionar ao ListView
            listView1.Items.Add(item);

            // Limpar os campos
            LimparCampos();

            MessageBox.Show("Pessoa adicionada com sucesso!");
        }

        // BOTÃO EDITAR (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            // Verificar se há um item selecionado
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecione uma pessoa para editar!");
                return;
            }

            // Validação
            if (string.IsNullOrWhiteSpace(pessoa.nome))
            {
                MessageBox.Show("Por favor, preencha o nome!");
                return;
            }

            // Editar o item selecionado
            ListViewItem item = listView1.SelectedItems[0];
            item.SubItems[0].Text = pessoa.nome;
            item.SubItems[1].Text = pessoa.email;
            item.SubItems[2].Text = pessoa.telefone;
            item.SubItems[3].Text = pessoa.categoria;

            LimparCampos();
            MessageBox.Show("Pessoa editada com sucesso!");
        }

        // BOTÃO REMOVER (button3)
        private void button3_Click(object sender, EventArgs e)
        {
            // Verificar se há um item selecionado
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecione uma pessoa para remover!");
                return;
            }

            // Confirmar remoção
            DialogResult resultado = MessageBox.Show(
                "Tem certeza que deseja remover esta pessoa?",
                "Confirmar Remoção",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                // Remover o item selecionado
                listView1.Items.Remove(listView1.SelectedItems[0]);
                LimparCampos();
                MessageBox.Show("Pessoa removida com sucesso!");
            }
        }

        // BOTÃO PESQUISAR (button4)
        private void button4_Click(object sender, EventArgs e)
        {
            string pesquisa = textBox1.Text.ToLower();

            if (string.IsNullOrWhiteSpace(pesquisa))
            {
                MessageBox.Show("Digite um nome para pesquisar!");
                return;
            }

            // Procurar no ListView
            bool encontrado = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.ToLower().Contains(pesquisa))
                {
                    // Selecionar o item encontrado
                    item.Selected = true;
                    item.EnsureVisible();
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado)
            {
                MessageBox.Show("Pessoa não encontrada!");
            }
        }

        // Quando seleciona um item no ListView, preenche os campos
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];

                textBox1.Text = item.SubItems[0].Text;
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
            }
        }

        // Método auxiliar para limpar os campos
        private void LimparCampos()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

            pessoa.nome = "";
            pessoa.email = "";
            pessoa.telefone = "";
            pessoa.categoria = "";
        }
    }
}